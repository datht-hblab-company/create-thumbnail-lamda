// index.mjs
import { S3Client, GetObjectCommand, PutObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";
import sharp from "sharp";
import path from "node:path";

const s3 = new S3Client({});

// Kích thước cần tạo
const WIDTHS = [50, 100, 200, 400, 600, 800, 1200];

// ENV tùy chọn
const {
  DEST_PREFIX = "resized/",     // luôn ghi vào resized/
  JPEG_QUALITY = "85",
  WEBP_QUALITY = "80",
  PNG_COMPRESSION = "9",
  // Whitelist section đầu (vd: "source,uploads"); để trống = không giới hạn
  ALLOWED_SECTIONS = ""
} = process.env;

const ALLOW = new Set(
  ALLOWED_SECTIONS.split(",").map(s => s.trim()).filter(Boolean)
);

// Chỉ xử lý các ext này
const ALLOWED_EXTS = new Set(["png", "jpg", "jpeg", "jfif"]);

// Map content-type theo ext (jpeg/jpg/jfif đều image/jpeg)
const CONTENT_TYPE_BY_EXT = {
  jpg:  "image/jpeg",
  jpeg: "image/jpeg",
  jfif: "image/jpeg",
  png:  "image/png",
  webp: "image/webp"
};

export const handler = async (event) => {
  const results = [];
  for (const record of event.Records ?? []) {
    try {
      const body = JSON.parse(record.body);
      const s3Records = body.Records ?? [];
      for (const r of s3Records) {
        if (!r.s3) continue;

        // Bucket dùng chung cho get & put
        const bucket = r.s3.bucket.name;
        const key = decodeURIComponent(r.s3.object.key.replace(/\+/g, " "));

        // Tách section đầu tiên
        const { firstSegment, remainder } = splitFirstSegment(key);
        if (!firstSegment || !remainder) continue;

        // Tránh vòng lặp: bỏ qua nếu section đầu là thư mục đích
        const destRoot = DEST_PREFIX.replace(/\/$/, "");
        if (firstSegment === destRoot) {
          console.log("Skip already-resized:", key);
          continue;
        }

        // (tùy chọn) chỉ cho phép một số section đầu
        if (ALLOW.size > 0 && !ALLOW.has(firstSegment)) {
          console.log(`Skip by whitelist: ${firstSegment} not in`, [...ALLOW]);
          continue;
        }

        // Kiểm tra ext từ tên file trước khi tải
        const base = path.posix.basename(remainder);
        const extFromName = (base.split(".").pop() || "").toLowerCase();
        if (!ALLOWED_EXTS.has(extFromName)) {
          console.log("Skip unsupported ext:", key);
          continue;
        }

        const res = await processOneObject({
          bucket,
          srcKey: key,
          firstSegment,        // ← truyền section đầu vào để ghép vào đường đích
          remainder,
          destRoot,
          extFromName
        });
        results.push(res);
      }
    } catch (err) {
      console.error("Error handling SQS record:", err);
      throw err; // để SQS retry
    }
  }
  return { statusCode: 200, body: JSON.stringify({ ok: true, results }) };
};

// ---------- Utilities & core ----------

function splitFirstSegment(key) {
  const norm = key.replace(/^\/+/, "");
  const parts = norm.split("/");
  const firstSegment = parts[0] || "";
  const remainder = parts.slice(1).join("/");
  return { firstSegment, remainder };
}

async function processOneObject({ bucket, srcKey, firstSegment, remainder, destRoot, extFromName }) {
  // remainder: phần path sau section đầu (vd "folderA/img.jpeg")
  const dir = path.posix.dirname(remainder);             // "folderA"
  const base = path.posix.basename(remainder);           // "img.jpeg"
  const name = base.slice(0, -(extFromName.length + 1)); // "img"

  // 1) Tải ảnh gốc
  const originalObj = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: srcKey }));
  const originalBuffer = await streamToBuffer(originalObj.Body);

  // 2) Metadata
  const img = sharp(originalBuffer, { failOn: "none" });
  const meta = await img.metadata();
  const maxOriginalW = meta.width || Infinity;

  // 3) Chuẩn hoá ext: GIỮ NGUYÊN ext gốc nếu thuộc ALLOWED_EXTS; nếu không, fallback theo meta
  const normalizedInputExt = normalizeExt(extFromName, meta.format);
  if (!ALLOWED_EXTS.has(normalizedInputExt)) {
    console.log("Skip after normalize (not in allowed):", srcKey, "->", normalizedInputExt);
    return { bucket, key: srcKey, ok: false, reason: "unsupported_ext" };
  }

  // 4) Xử lý từng width
  for (const w of WIDTHS) {
    const targetW = Math.min(w, maxOriginalW);

    // 4.1) Bản theo ĐỊNH DẠNG GỐC (giữ nguyên ext png/jpg/jpeg/jfif)
    const { buffer: resizedBuf, outExt, contentType } = await toOriginalFormat(
      img, targetW, normalizedInputExt, {
        jpegQuality: parseInt(JPEG_QUALITY, 10),
        pngCompression: parseInt(PNG_COMPRESSION, 10)
      }
    );

    const dstKeyOriginal = path.posix.join(
      destRoot,                 // "resized"
      firstSegment,             // "source" (giữ nguyên section đầu)
      dir === "." ? "" : dir,   // "folderA"
      `${name}-w${w}.${outExt}` // "img-w200.jpeg"
    ).replace(/\/+/g, "/");

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: dstKeyOriginal,
      Body: resizedBuf,
      ContentType: contentType
    }));

    // 4.2) Bản WEBP
    const webpBuf = await img.clone()
      .resize({ width: targetW, withoutEnlargement: true })
      .webp({ quality: parseInt(WEBP_QUALITY, 10) })
      .toBuffer();

    const dstKeyWebp = path.posix.join(
      destRoot,
      firstSegment,
      dir === "." ? "" : dir,
      `${name}-w${w}.webp`
    ).replace(/\/+/g, "/");

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: dstKeyWebp,
      Body: webpBuf,
      ContentType: "image/webp"
    }));
  }

  return { bucket, key: srcKey, ok: true };
}

/**
 * GIỮ NGUYÊN ext gốc nếu thuộc ALLOWED_EXTS.
 * Nếu ext tên file lạ, thử đọc meta.format (jpeg/png/…); nếu là jpeg -> chọn "jpeg".
 * Nếu vẫn không hợp lệ, fallback "jpg" (nhưng sẽ bị chặn bởi ALLOWED_EXTS check phía trên).
 */
function normalizeExt(ext, metaFormat) {
  const e = (ext || "").toLowerCase();
  const f = (metaFormat || "").toLowerCase();

  // Nếu ext từ tên file đã hợp lệ -> giữ nguyên
  if (ALLOWED_EXTS.has(e)) return e;

  // Fallback theo metadata
  if (f === "jpeg") return "jpeg";
  if (f === "png")  return "png";

  // Fallback cuối
  return "jpg";
}

/**
 * Xuất đúng định dạng gốc: png/jpg/jpeg/jfif (đều dùng encoder PNG hoặc JPEG).
 * Với jfif: nội dung vẫn là JPEG binary, chỉ khác phần đuôi file; Content-Type = image/jpeg.
 */
async function toOriginalFormat(img, width, ext, opts) {
  const base = img.clone().resize({ width, withoutEnlargement: true });

  switch (ext) {
    case "jpg":
    case "jpeg":
    case "jfif":
      return {
        buffer: await base.jpeg({ quality: opts.jpegQuality, mozjpeg: true }).toBuffer(),
        outExt: ext, // giữ nguyên jpg/jpeg/jfif
        contentType: CONTENT_TYPE_BY_EXT[ext]
      };

    case "png":
      return {
        buffer: await base.png({ compressionLevel: opts.pngCompression }).toBuffer(),
        outExt: "png",
        contentType: CONTENT_TYPE_BY_EXT.png
      };

    default:
      // Không xảy ra vì đã lọc ALLOWED_EXTS, nhưng để safety vẫn trả JPEG
      return {
        buffer: await base.jpeg({ quality: opts.jpegQuality, mozjpeg: true }).toBuffer(),
        outExt: "jpg",
        contentType: CONTENT_TYPE_BY_EXT.jpg
      };
  }
}

async function streamToBuffer(stream) {
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function exists(bucket, key) {
  try {
    await s3.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
    return true;
  } catch {
    return false;
  }
}
